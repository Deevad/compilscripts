#!/bin/sh
# by David Revoy , version 0.1a
# Inspired by :
# Spell script : http://pastebin.com/KkT9SvTs
# Kubuntiac script : http://forum.kde.org/viewtopic.php?f=139&t=92880

# Project name
project=vc

# Help page
helppage=http://www.davidrevoy.com

# Root directory
directory=$HOME/Software

# Subfolder
srcDir=$directory/$project/src
buildDir=$directory/$project/build

# CPU available
numCores=$((`cat /proc/cpuinfo | grep processor | wc -l`))

# Git repository adress
gitRepo=git://gitorious.org/vc/vc.git

_setup_dir()
{
	mkdir -p $srcDir
	mkdir -p $instDir
	mkdir -p $buildDir
}

_done()
{
	echo "Done."
	echo "Thanks for using the $project-install.sh script"
	echo "-----------------------------------------------"
}

_install_dependencies()
{
	echo "This part will install all the dependencies for building $project"
	echo "the system will be updated and new package installed"
	echo -n "press [Enter] to continue, or [Ctrl+C] to abort"
	read CHOICE
	sudo apt-get -y update
	sudo apt-get -y upgrade
	sudo apt-get -y install build-essential git cmake
	sudo apt-get -f install
}

_get_sources()
{
	cd $directory/$project/
	git clone $gitRepo src
}

_compile_sources()
{
	cd $buildDir
	cmake ../src
	make -j$numCores
	sudo make install -j$numCores
}

_update_sources()
{
	cd $srcDir
	git pull
}

_user_install()
{
	echo "------------------------------------------------------"
	echo "INSTALLATION"
	echo "------------------------------------------------------"
	echo "      "
	_setup_dir
	_install_dependencies
	_get_sources
	_update_sources
	_compile_sources
	_done
}

_user_update()
{
	echo "------------------------------------------------------"
	echo "UPDATE"
	echo "------------------------------------------------------"
	echo "      "
	_update_sources
	_compile_sources
	_done
}

#######
# UI  #
#######

clear
echo "█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█"
echo "█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒  $project-install.sh █▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█"
echo "█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█"
echo "      "
echo "A script to help you to compile, update, and follow the development of $project"
echo "made for Linux Mint KDE 14"
echo "      "
# menu
echo "------------------------------------------------------"
echo "1) Install"
echo "2) Update"
echo "3) Open sources folder"
echo "4) Help webpage"
echo " "
echo "(Ctrl+C to exit)"
echo "------------------------------------------------------"
echo -n "enter your choice : ?"
read mainmenu
echo " "
echo " "
	if [ "$mainmenu" = 1 ]; then
		_user_install
		
	elif [ "$mainmenu" = 2 ]; then
		_user_update

	elif [ "$mainmenu" = 3 ]; then
		cd $srcDir
		
	elif [ "$mainmenu" = 4 ]; then
		xdg-open $helppage
	else
	echo "the script couldn't understand your choice, try again...";
	fi;
cd $directory