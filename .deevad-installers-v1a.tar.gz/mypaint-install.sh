#!/bin/sh
# by David Revoy , version 0.1a
# Inspired by :
# Spell script : http://pastebin.com/KkT9SvTs
# Kubuntiac script : http://forum.kde.org/viewtopic.php?f=139&t=92880

# Project name
project=mypaint

# Help page
helppage=http://www.davidrevoy.com

# Root directory
directory=$HOME/Software

# Subfolder
srcDir=$directory/$project

# Git repository adress
gitRepo=git://gitorious.org/mypaint/mypaint.git

_setup_dir()
{
	mkdir -p $srcDir
}

_done()
{
	echo "Done."
	echo "Thanks for using the $project-install.sh script"
	echo "-----------------------------------------------"
}

_install_dependencies()
{
	echo "This part will install all the dependencies for building $project"
	echo "the repositories will be updated then new package installed"
	echo  "Also, every $project package installed will be automatically uninstalled"
	echo -n "press [Enter] to continue, or [Ctrl+C] to abort"
	read CHOICE
	sudo apt-get -y update
	sudo apt-get purge mypaint*
	sudo apt-get -y install build-essential git libgtk2.0-dev python-gtk2-dev git-core g++ python-dev libglib2.0-dev python-numpy swig scons gettext libpng12-dev liblcms2-dev libjson0-dev
	sudo apt-get -f install
}

_get_sources()
{
	cd $directory
	git clone $gitRepo $project
}

_compile_sources()
{
	cd $srcDir
	sudo scons prefix=/usr/local install
}

_update_sources()
{
	cd $srcDir
	git pull
}

_user_install()
{
	echo "------------------------------------------------------"
	echo "INSTALLATION"
	echo "------------------------------------------------------"
	echo "      "
	_setup_dir
	_install_dependencies
	_get_sources
	_update_sources
	_compile_sources
	_done
}

_user_update()
{
	echo "------------------------------------------------------"
	echo "UPDATE"
	echo "------------------------------------------------------"
	echo "      "
	_update_sources
	_compile_sources
	_done
}

_user_compile_only()
{
	echo "------------------------------------------------------"
	echo "COMPILE ONLY"
	echo "------------------------------------------------------"
	echo "      "
	_compile_sources
	_done
}

_user_reset_to_stable()
{
	echo "------------------------------------------------------"
	echo "RESET TO STABLE 1.1"
	echo "------------------------------------------------------"
	echo "      "
	cd $srcDir
	git checkout v1.1.0
	git clean -dfx
	_compile_sources
	_done
}
_user_reset_master()
{
	echo "------------------------------------------------------"
	echo "RESET TO MASTER"
	echo "------------------------------------------------------"
	echo "      "
	cd $srcDir
	git reset --hard master
	git pull
	git clean -dfx
	_compile_sources
	_done
}


#######
# UI  #
#######

clear
echo "█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█"
echo "█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒  $project-install.sh █▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█"
echo "█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█▒█"
echo "      "
echo "A script to help you to compile, update, and follow the development of $project"
echo "made for Linux Mint KDE 14"
echo "      "
# menu
echo "------------------------------------------------------"
echo "1) Install"
echo "2) Update"
echo "3) Compile only"
echo "4) Reset to master"
echo "5) Reset to stable 1.1"
echo "6) Help webpage"
echo " "
echo "(Ctrl+C to exit)"
echo "------------------------------------------------------"
echo -n "enter your choice : ?"
read mainmenu
echo " "
echo " "
	if [ "$mainmenu" = 1 ]; then
		_user_install
		
	elif [ "$mainmenu" = 2 ]; then
		_user_update
		
	elif [ "$mainmenu" = 3 ]; then
		_user_compile_only

	elif [ "$mainmenu" = 4 ]; then
		_user_reset_master
		
	elif [ "$mainmenu" = 5 ]; then
		_user_reset_to_stable
		
	elif [ "$mainmenu" = 6 ]; then
		xdg-open $helppage
	else
	echo "the script couldn't understand your choice, try again...";
	fi;
cd $directory